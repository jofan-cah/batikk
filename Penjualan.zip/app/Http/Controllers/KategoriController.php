<?php

namespace App\Http\Controllers;

use App\Models\Kategori;
use Illuminate\Http\Request;

class KategoriController extends Controller
{
	public function index()
	{
		$kategori = Kategori::all();

		return view('kategori/index', ['kategori' => $kategori]);
	}

	public function tambah()
	{
		return view('kategori.form');
	}

	public function simpan(Request $request)
	{
		$data = [
			'id_harga' => $request->id_harga,
			'sku' => $request->sku,
			'harga' => $request->harga,
			'diskon' => $request->diskon,
			'tgl_berlaku' => $request->tgl_berlaku,
			'kode_cp' => $request->kode_cp,
			'tgl_del' => $request->tgl_del,
			'diskon_psn' => $request->diskon_psn,
			'updat' => $request->updat
		];
		Kategori::create($data);

		return redirect()->route('kategori');
	}

	public function edit($id_harga)
	{


		$kategori = Kategori::find($id_harga);

		return view('kategori.form', ['kategori' => $kategori]);
	}

	public function update($id_harga, Request $request)
	{
		$data = [
			'id_harga' => $request->id_harga,
			'sku' => $request->sku,
			'harga' => $request->harga,
			'diskon' => $request->diskon,
			'tgl_berlaku' => $request->tgl_berlaku,
			'kode_cp' => $request->kode_cp,
			'tgl_del' => $request->tgl_del,
			'diskon_psn' => $request->diskon_psn,
			'updat' => $request->updat
		];
		Kategori::find($id_harga)->update($data);

		return redirect()->route('kategori');
	}
	public function hapus($id_harga)
	{
		Kategori::find($id_harga)->delete();

		return redirect()->route('barang');
	}
}
