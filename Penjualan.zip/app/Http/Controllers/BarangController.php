<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use App\Models\Kategori;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BarangController extends Controller
{
	public function index()
	{
		$barang = Barang::all();
		$data = DB::table('barang')
			->join('users', 'users.id', '=', 'barang.updat')
			->get();

		return view('barang.index', ['data' => $data]);
	}

	public function tambah()
	{
		return view('barang.form');
	}

	public function simpan(Request $request)
	{
		$data = [
			'sku' => $request->sku,
			'korner' => $request->korner,
			'produk' => $request->produk,
			'model' => $request->model,
			'motif' => $request->motif,
			'korner' => $request->korner,
			'produk' => $request->produk,
			'model' => $request->model,
			'motif' => $request->motif,
			'proses' => $request->proses,
			'material' => $request->material,
			'warna' => $request->warna,
			'rasa' => $request->rasa,
			'brand' => $request->brand,
			'size' => $request->size,
			'satuan' => $request->satuan,
			'status' => $request->status,
			'sup' => $request->sup,
			'asal' => $request->asal,
			'pt' => $request->pt,
			'updat' => $request->updat
		];

		Barang::create($data);

		return redirect()->route('barang');
	}

	public function edit($id)
	{
		$barang = Barang::find($id);



		return view('barang.form', ['barang' => $barang]);
	}

	public function update($id, Request $request)
	{
		$data = [
			'sku' => $request->sku,
			'korner' => $request->korner,
			'produk' => $request->produk,
			'model' => $request->model,
			'motif' => $request->motif,
			'korner' => $request->korner,
			'produk' => $request->produk,
			'model' => $request->model,
			'motif' => $request->motif,
			'proses' => $request->proses,
			'material' => $request->material,
			'warna' => $request->warna,
			'rasa' => $request->rasa,
			'brand' => $request->brand,
			'size' => $request->size,
			'satuan' => $request->satuan,
			'status' => $request->status,
			'sup' => $request->sup,
			'asal' => $request->asal,
			'pt' => $request->pt,
			'updat' => $request->updat
		];

		Barang::find($id)->update($data);

		return redirect()->route('barang');
	}

	public function hapus($id)
	{
		Barang::find($id)->delete();

		return redirect()->route('barang');
	}
}
